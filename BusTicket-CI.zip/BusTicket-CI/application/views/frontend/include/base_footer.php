			<footer class="footer-area section-gap">
				<div class="container">
					<div class="row">
						<div class="col-lg-3  col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h4 class="text-white">Bus Ticket Booking</h4>
								<p>
								BUS Tickets is the largest online bus ticket booking service in the world. Trusted by more than 8 million customers globally. Bus Tickets offers booking bus tickets through the website.
								</p>
							</div>
						</div>
						<div class="col-lg-4  col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h4 class="text-white">Contact Us</h4>
								<p>

								</p>
								<p class="number">
									012-0101-111-1001 <br>
									012-1010-000-0110
								</p>
							</div>
						</div>						
						<div class="col-lg-5  col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h4 class="text-white">Newsletter</h4>
								<p>You can trust us. we only send  offers, not a single spam.</p>
								<div class="d-flex flex-row" id="mc_embed_signup">
										<form class="navbar-form" novalidate="true" action="" method="post">
									    <div class="input-group add-on">
									      	<input class="form-control" placeholder="Email address"  type="email">
											<div style="position: absolute; left: -5000px;">
												<input name="" tabindex="-1" value="" type="text">
											</div>
									      <div class="input-group-btn">
									        <button class="genric-btn primary circle arrow"><span class="lnr lnr-arrow-right"></span></button>
									      </div>
									    </div>
									      <div class="info mt-20"></div>									    
									  </form>

								</div>
							</div>
						</div>						
					</div>
					<div class="footer-bottom d-flex justify-content-between align-items-center flex-wrap">
						<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            <p class="footer-text m-0"><span>&copy; <?= date('Y') ?> Bus Ticket Booking System - Developed by Bahyu Sanciko </span> </p>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
			<!-- Log on to codeastro.com for more projects -->
						<!-- <div class="footer-social d-flex align-items-center">
							<a href="#"><i class="fas fa-facebook"></i></a>
							<a href="#"><i class="fas fa-twitter"></i></a>
							<a href="#"><i class="fas fa-dribbble"></i></a>
							<a href="#"><i class="fas fa-behance"></i></a>
						</div> -->
					</div>
				</div>
			</footer>
			<div class="preloader">
			<div class="loading">
				<img src="<?php echo base_url('assets/frontend/img/preloader.gif') ?>" width="100">
				<p>Please Wait...</p>
			</div>
		</div>	
			<!-- End footer Area -->